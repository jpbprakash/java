//Q17. WAP to print table of a given number.
package JAVA_Lab_File;

public class Q17_Table_of_a_no {

    public static void main(String[] args) {
        int n = 5;
        for (int i = 1; i <= 10; i++) {
            System.out.println(n + " * " + i + " = " + n * i);
        }
    }
}

